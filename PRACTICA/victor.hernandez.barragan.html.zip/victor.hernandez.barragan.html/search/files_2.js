var searchData=
[
  ['lista_5fjugadores_2ehh_69',['Lista_Jugadores.hh',['../_lista___jugadores_8hh.html',1,'']]],
  ['lista_5ftorneos_2ehh_70',['Lista_Torneos.hh',['../_lista___torneos_8hh.html',1,'']]]
];
