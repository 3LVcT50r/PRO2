var indexSectionsWithContent =
{
  0: "bcefijlmnt~",
  1: "cjlt",
  2: "cjlmt",
  3: "bcefijlmnt~",
  4: "c"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "pages"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Archivos",
  3: "Funciones",
  4: "Páginas"
};

