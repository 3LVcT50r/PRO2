var searchData=
[
  ['categorias_75',['Categorias',['../class_categorias.html#acf3862e9c17464d9e7ef0c242a0f9276',1,'Categorias::Categorias(const Categorias &amp;cat)'],['../class_categorias.html#a9c8353e5665cf7c4f64d7165776518ac',1,'Categorias::Categorias()']]],
  ['cons_5fcategoria_76',['cons_categoria',['../class_torneo.html#af3c8be9b7b20fdc4d5d0f336dc8eb86b',1,'Torneo']]],
  ['cons_5festado_5ftorneo_77',['cons_estado_torneo',['../class_torneo.html#a990567c008907014cde589f5ad0c954a',1,'Torneo']]],
  ['cons_5fjuegg_78',['cons_juegg',['../class_jugador.html#ac58faa922e810aade0e051cc75cbedfd',1,'Jugador']]],
  ['cons_5fjuegp_79',['cons_juegp',['../class_jugador.html#a9b9ab53e8fd3b5e6260c57981286d400',1,'Jugador']]],
  ['cons_5fpartg_80',['cons_partg',['../class_jugador.html#a0e2b81f1310f51f7f38c085e70d771cc',1,'Jugador']]],
  ['cons_5fpartp_81',['cons_partp',['../class_jugador.html#a3f0ac56221529d820a55478b3c01e934',1,'Jugador']]],
  ['cons_5fpuntos_5ftotales_82',['cons_puntos_totales',['../class_torneo.html#ae4dffad46dbc6f2ef886fc4c9659e315',1,'Torneo']]],
  ['cons_5fpuntos_5ftotales_5fpor_5fcat_83',['cons_puntos_totales_por_cat',['../class_categorias.html#ac145113edef934ad600e9157c10a579d',1,'Categorias']]],
  ['cons_5fsetsg_84',['cons_setsg',['../class_jugador.html#ab2125ebfae69f0ef23c6928d6081a746',1,'Jugador']]],
  ['cons_5fsetsp_85',['cons_setsp',['../class_jugador.html#a53101e3d40689b597117964cd6ae7e71',1,'Jugador']]],
  ['cons_5ftorn_5fjugados_86',['cons_torn_jugados',['../class_jugador.html#af6b1d11752c3296aa837b1ed4c856fba',1,'Jugador']]],
  ['consultar_5fjugador_87',['consultar_jugador',['../class_lista___jugadores.html#a3744b787001689a6f5e91ff0654b2dac',1,'Lista_Jugadores']]],
  ['consultar_5fnombre_88',['consultar_nombre',['../class_categorias.html#a2e49516e59bde184d9aa37cf09b9301a',1,'Categorias']]],
  ['consultar_5fpuntos_5fpor_5fnivel_89',['consultar_puntos_por_nivel',['../class_categorias.html#a7ef5909c77e5204062806480315456f6',1,'Categorias']]],
  ['consultar_5ftorneo_90',['consultar_torneo',['../class_lista___torneos.html#afceb776eb35f3386c62b1bdd4fde6904',1,'Lista_Torneos']]]
];
