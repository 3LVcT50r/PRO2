var searchData=
[
  ['nuevo_5fjugador_51',['nuevo_jugador',['../class_lista___jugadores.html#ab1cbd5916347a5c8ab8102e90fde518b',1,'Lista_Jugadores']]],
  ['nuevo_5ftorneo_52',['nuevo_torneo',['../class_lista___torneos.html#a3bd7f0399801a4a067f4641e554ea16b',1,'Lista_Torneos']]],
  ['num_5fjugadores_53',['num_jugadores',['../class_lista___jugadores.html#acde1fcb983f382e2d1aeb6af661157c8',1,'Lista_Jugadores']]],
  ['numero_5ftorneos_54',['numero_torneos',['../class_lista___torneos.html#a0e0c54f7c0e4cca8681cad581c452418',1,'Lista_Torneos']]]
];
