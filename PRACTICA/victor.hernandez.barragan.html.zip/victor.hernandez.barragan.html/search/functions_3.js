var searchData=
[
  ['finalizar_5ftorneo_93',['finalizar_torneo',['../class_lista___torneos.html#a3c96072f292325323c53c9cd57dca4f0',1,'Lista_Torneos']]]
];
