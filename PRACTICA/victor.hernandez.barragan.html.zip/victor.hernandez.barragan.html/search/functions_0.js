var searchData=
[
  ['baja_5fjugador_73',['baja_jugador',['../class_lista___jugadores.html#aa6c15ff97e5d61b6e4358a2f0a136f36',1,'Lista_Jugadores']]],
  ['baja_5ftorneo_74',['baja_torneo',['../class_lista___torneos.html#a1b2831c91142cb0780daff9ba68652e6',1,'Lista_Torneos']]]
];
