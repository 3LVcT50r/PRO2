var searchData=
[
  ['torneo_121',['Torneo',['../class_torneo.html#a7bf6d35a7ec8d0e13a0bed8deb8add3e',1,'Torneo::Torneo()'],['../class_torneo.html#a83f583185350607882fb72e0e7f53771',1,'Torneo::Torneo(int c)'],['../class_torneo.html#acbc67ef02645074cb14ec98d908bebf2',1,'Torneo::Torneo(const Torneo &amp;torn)']]]
];
