var searchData=
[
  ['jugador_97',['Jugador',['../class_jugador.html#a232c46f75691af6210096e5972535d71',1,'Jugador::Jugador()'],['../class_jugador.html#ac4d14698e6ae102c0c08f4a38bae404e',1,'Jugador::Jugador(const Jugador &amp;jug)']]]
];
