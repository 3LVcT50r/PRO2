var searchData=
[
  ['identificador_5fjugador_23',['identificador_jugador',['../class_lista___jugadores.html#a256482f319a8953b5c21b0878eb13fe0',1,'Lista_Jugadores']]],
  ['identificador_5ftorneo_24',['identificador_torneo',['../class_lista___torneos.html#aa9024eb13fa9aa934474851a768de66b',1,'Lista_Torneos']]],
  ['iniciar_5ftorneo_25',['iniciar_torneo',['../class_lista___torneos.html#ae02b391fd5b16455cc485832ce7cadf6',1,'Lista_Torneos']]]
];
