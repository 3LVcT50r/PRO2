var searchData=
[
  ['lista_5fjugadores_64',['Lista_Jugadores',['../class_lista___jugadores.html',1,'']]],
  ['lista_5ftorneos_65',['Lista_Torneos',['../class_lista___torneos.html',1,'']]]
];
