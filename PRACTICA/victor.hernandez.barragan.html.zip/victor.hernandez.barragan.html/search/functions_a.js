var searchData=
[
  ['_7ecategorias_122',['~Categorias',['../class_categorias.html#a358cd5f1187e6978c28e3b9ca17b98e4',1,'Categorias']]],
  ['_7ejugador_123',['~Jugador',['../class_jugador.html#a9db1d422fe3b675f92d9fd687b1f42c4',1,'Jugador']]],
  ['_7elista_5fjugadores_124',['~Lista_Jugadores',['../class_lista___jugadores.html#aff18a2b096f1baef44e6d5f5d565d5e7',1,'Lista_Jugadores']]],
  ['_7elista_5ftorneo_125',['~Lista_Torneo',['../class_lista___torneos.html#a013af76ca877fa2b6b5dbca98c45702b',1,'Lista_Torneos']]],
  ['_7etorneo_126',['~Torneo',['../class_torneo.html#af733d8f40440880674a88c8918baf19c',1,'Torneo']]]
];
