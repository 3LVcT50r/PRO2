var searchData=
[
  ['escribir_5femparejamientos_20',['escribir_emparejamientos',['../class_torneo.html#a043a59da05c8c40696d55584398ae13c',1,'Torneo']]],
  ['escribir_5fresultados_5ftorneo_21',['escribir_resultados_torneo',['../class_torneo.html#a614d9e6fe80b283c16b57d008e7e88ea',1,'Torneo']]]
];
