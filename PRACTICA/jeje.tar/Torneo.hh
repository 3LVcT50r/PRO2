/** @file Torneo.hh
    @brief Especificacion de la clase Torneo
*/

#ifndef _TORNEO_HH_
#define _TORNEO_HH_

#include "Jugador.hh"
#include "Lista_Jugadores.hh"
#include "Categorias.hh"

#ifndef NO_DIAGRAM
#include <string>
#include "BinTree.hh"
#include <vector>
#include <map>
#include <cmath>
#include <iostream>
using namespace std;
typedef vector< vector<int> > Matriz;
#endif

/** @class Torneo
    @brief Representa a un torneo con ciertos atrivutos y sus operaciones.
*/
class Torneo {

private:

  int cat;
  int num_participantes;

  //Arboles de emparejamientos y resultados
  BinTree<int> part;
  BinTree<int> res;
  BinTree<string> punt;

  vector<string> participantes;       //Cada i de los dos vectores tienen
  vector<int> puntos_jugador;         //que corresponder al mismo jugador.
  
  //Historial de los jugadores
  vector<string> ant_participantes;
  vector<int> ant_puntos_jugador;

  Matriz est_local;
    // j = 0 -> WM;
    // j = 1 -> LM;
    // j = 2 -> WS;
    // j = 3 -> LS;
    // j = 4 -> WG;
    // j = 5 -> LG;
    // j = 6 -> nivel;

  static void arbol_emp(BinTree<int> &a, const vector<string> &v, int l, bool &cond);

  void act_puntos_viejo_torneo(Lista_Jugadores &ljug);

  static void arbol_punt(BinTree<string> &a);

  static int winner(int a, int b, const string &x);

  static void arbol_res(BinTree<int> &a, const BinTree<int> &part, const BinTree<string> &punt);

  void mod_puntos(const BinTree<int> &res, int l);

  void anadir_est_matriz(int &j1, int &j2, const string &puntos);

  void imprimir_res(const BinTree<int> &res, const BinTree<string> &punt, const vector<string> &part);

  void imprimir_puntos(const vector<string> &part, const Matriz &est, vector<int> &punt, const Categorias &lcat);

public:

  //Constructora
  
  /** @brief Creadora por defecto. 

      Se ejecuta automáticamente al declarar un torneo.
      \pre <em>cierto</em>
      \post El resultado es un torneo no inicializado.
  */
  Torneo();

  /** @brief Creadora con la categoría preseleccionada. 

      \pre c >= 0 y t tiene que ser un identificador válido.
      \post El resultado es un torneo inicializado con el identificador y la categoría.
  */
  Torneo(const int &c);

  //Modificadoras

  /** @brief Se inicia un torneo.

      \pre v tiene que tener los strings en orden de ranking
      \post Se inicia el torneo.
  */
  void inic_torneo(const vector<string> &v, const int &n);

  void fini_torneo(Lista_Jugadores &ljug, const Categorias &lcat);

  void act_puntos_baja_jug(const string &p);

  void act_est_baja_torneo(Lista_Jugadores &ljug);

  //Consultoras

  bool hay_historial() const;

  /** @brief Consultora de la categoría del torneo.
    
      \pre <em>cierto</em>
      \post El resultado te dice en que categoría está el torneo.
  */
  int cons_categoria() const;
};

#endif