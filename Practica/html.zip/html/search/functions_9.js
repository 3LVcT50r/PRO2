var searchData=
[
  ['nuevo_5fjugador_175',['nuevo_jugador',['../class_lista___jugadores.html#af3d258d09e11524403503496e9dd0079',1,'Lista_Jugadores']]],
  ['nuevo_5ftorneo_176',['nuevo_torneo',['../class_lista___torneos.html#ae069a1a3b66f407618fa723e024bfc02',1,'Lista_Torneos']]],
  ['num_5fjugadores_177',['num_jugadores',['../class_lista___jugadores.html#acde1fcb983f382e2d1aeb6af661157c8',1,'Lista_Jugadores']]],
  ['num_5ftorneos_178',['num_torneos',['../class_lista___torneos.html#acc354eb8ca24ea82e99fd7303a75df9c',1,'Lista_Torneos']]]
];
