var searchData=
[
  ['baja_5fjugador_129',['baja_jugador',['../class_lista___jugadores.html#acc5254c4440ecdb9567d114181e4c8d9',1,'Lista_Jugadores']]],
  ['baja_5ftorneo_130',['baja_torneo',['../class_lista___torneos.html#a3ce5753ff35cec172646c3eeae154297',1,'Lista_Torneos']]]
];
