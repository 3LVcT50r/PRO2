var searchData=
[
  ['p_5flvl_83',['p_lvl',['../class_categorias.html#abb93c109817d9436b34a0838e3f97e27',1,'Categorias']]],
  ['part_84',['part',['../class_torneo.html#a116a304780ce7b8851e18cd5645af4cf',1,'Torneo']]],
  ['participantes_85',['participantes',['../class_torneo.html#a7c3b2492fa8c9faeb7ef18c55b7aaee3',1,'Torneo']]],
  ['program_2ecc_86',['program.cc',['../program_8cc.html',1,'']]],
  ['punt_87',['punt',['../class_torneo.html#a886b888273fd5ab439590a2121c57ace',1,'Torneo']]],
  ['punti_88',['punti',['../struct_lista___jugadores_1_1_ranking.html#ad3289cbbfb9862a0833a9e5a454cc9f3',1,'Lista_Jugadores::Ranking']]],
  ['puntos_89',['puntos',['../class_jugador.html#a4e264d857d5a3f1a68cbb13e4b88930f',1,'Jugador']]],
  ['puntos_5fjugador_90',['puntos_jugador',['../class_torneo.html#ab43c2475011d1768cb2fce6382bf65bc',1,'Torneo']]]
];
