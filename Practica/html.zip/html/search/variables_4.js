var searchData=
[
  ['nom_191',['nom',['../class_categorias.html#a7a69d8252e0a5e89f1b00d4bdbe6b24a',1,'Categorias']]],
  ['nombre_192',['nombre',['../struct_lista___jugadores_1_1_ranking.html#ab5524b619ee32e8ba882e29386382edb',1,'Lista_Jugadores::Ranking']]],
  ['numero_5fcategorias_193',['numero_categorias',['../class_categorias.html#a9ea549720099db3b48943515d0241307',1,'Categorias']]],
  ['numero_5fjugadores_194',['numero_jugadores',['../class_lista___jugadores.html#a0b6bf513055773dcfcca635be585f669',1,'Lista_Jugadores']]],
  ['numero_5ftorneos_195',['numero_torneos',['../class_lista___torneos.html#a7c0f945b50a6fd804148730f3558178d',1,'Lista_Torneos']]]
];
