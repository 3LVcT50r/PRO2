var searchData=
[
  ['ranki_91',['ranki',['../struct_lista___jugadores_1_1_ranking.html#a20a8a9d8275a99e2fc63c5319ae12711',1,'Lista_Jugadores::Ranking']]],
  ['ranking_92',['Ranking',['../struct_lista___jugadores_1_1_ranking.html',1,'Lista_Jugadores']]],
  ['ranking_93',['ranking',['../class_lista___jugadores.html#a455fdd21af17a5bba419a8194b8b4134',1,'Lista_Jugadores::ranking()'],['../class_jugador.html#abfd82fbfa2e58fdd634c94f7bc11c66b',1,'Jugador::ranking()']]],
  ['res_94',['res',['../class_torneo.html#ade79bf633919efe994e5bcb7b19bdddf',1,'Torneo']]]
];
