var searchData=
[
  ['act_5fbaja_5fjugador_0',['act_baja_jugador',['../class_lista___torneos.html#a1e7c0b52aa223735ab2b7dbb87b7b707',1,'Lista_Torneos']]],
  ['act_5fest_5fbaja_5ftorneo_1',['act_est_baja_torneo',['../class_torneo.html#a494ffc62aeeb9b9d0d39a83db0e41a24',1,'Torneo']]],
  ['act_5fpunt_5fjug_2',['act_punt_jug',['../class_lista___jugadores.html#a86113ba11b583ee36e2895080544593d',1,'Lista_Jugadores']]],
  ['act_5fpuntos_5fbaja_5fjug_3',['act_puntos_baja_jug',['../class_torneo.html#a999bd4191847a716f4068bc775bb33a6',1,'Torneo']]],
  ['act_5fpuntos_5fviejo_5ftorneo_4',['act_puntos_viejo_torneo',['../class_torneo.html#aa6f30101e0c60eec0e51f8e1fff63152',1,'Torneo']]],
  ['anadir_5fest_5fmatriz_5',['anadir_est_matriz',['../class_torneo.html#a294584f79c8955902ac42c18dd0ed3b8',1,'Torneo']]],
  ['ant_5fparticipantes_6',['ant_participantes',['../class_torneo.html#a7a75e43b363430c6a0ae2fd83e57649b',1,'Torneo']]],
  ['ant_5fpuntos_5fjugador_7',['ant_puntos_jugador',['../class_torneo.html#ad1600dd87d7097af0fee631cb1233637',1,'Torneo']]],
  ['arbol_5femp_8',['arbol_emp',['../class_torneo.html#a3543532c4ea2e266886c5e159b346766',1,'Torneo']]],
  ['arbol_5fpunt_9',['arbol_punt',['../class_torneo.html#a2301df411e586abaeb0bbea0c8253305',1,'Torneo']]],
  ['arbol_5fres_10',['arbol_res',['../class_torneo.html#ac3838de9668142370e6228e0cadf30b0',1,'Torneo']]]
];
