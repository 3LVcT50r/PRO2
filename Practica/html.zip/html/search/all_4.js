var searchData=
[
  ['finalizar_5ftorneo_34',['finalizar_torneo',['../class_lista___torneos.html#a2b37e40daac30bef87b2f95c796c702c',1,'Lista_Torneos']]],
  ['fini_5ftorneo_35',['fini_torneo',['../class_torneo.html#a68bdf649d0c9a527eb75e5e333e86975',1,'Torneo']]]
];
