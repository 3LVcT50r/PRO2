var searchData=
[
  ['torn_5fjugados_206',['torn_jugados',['../class_jugador.html#a8ca80640d927c6596cb6668a201aeef9',1,'Jugador']]]
];
