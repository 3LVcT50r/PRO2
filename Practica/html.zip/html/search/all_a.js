var searchData=
[
  ['nom_73',['nom',['../class_categorias.html#a7a69d8252e0a5e89f1b00d4bdbe6b24a',1,'Categorias']]],
  ['nombre_74',['nombre',['../struct_lista___jugadores_1_1_ranking.html#ab5524b619ee32e8ba882e29386382edb',1,'Lista_Jugadores::Ranking']]],
  ['nuevo_5fjugador_75',['nuevo_jugador',['../class_lista___jugadores.html#af3d258d09e11524403503496e9dd0079',1,'Lista_Jugadores']]],
  ['nuevo_5ftorneo_76',['nuevo_torneo',['../class_lista___torneos.html#ae069a1a3b66f407618fa723e024bfc02',1,'Lista_Torneos']]],
  ['num_5fjugadores_77',['num_jugadores',['../class_lista___jugadores.html#acde1fcb983f382e2d1aeb6af661157c8',1,'Lista_Jugadores']]],
  ['num_5ftorneos_78',['num_torneos',['../class_lista___torneos.html#acc354eb8ca24ea82e99fd7303a75df9c',1,'Lista_Torneos']]],
  ['numero_5fcategorias_79',['numero_categorias',['../class_categorias.html#a9ea549720099db3b48943515d0241307',1,'Categorias']]],
  ['numero_5fjugadores_80',['numero_jugadores',['../class_lista___jugadores.html#a0b6bf513055773dcfcca635be585f669',1,'Lista_Jugadores']]],
  ['numero_5ftorneos_81',['numero_torneos',['../class_lista___torneos.html#a7c0f945b50a6fd804148730f3558178d',1,'Lista_Torneos']]]
];
