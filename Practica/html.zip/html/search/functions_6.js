var searchData=
[
  ['jugador_156',['Jugador',['../class_jugador.html#a232c46f75691af6210096e5972535d71',1,'Jugador']]]
];
