var searchData=
[
  ['winner_181',['winner',['../class_torneo.html#a1e1aad3a08d531e8597d8a8e55d542ea',1,'Torneo']]]
];
