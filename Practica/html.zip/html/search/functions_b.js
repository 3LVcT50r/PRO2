var searchData=
[
  ['torneo_180',['Torneo',['../class_torneo.html#a7bf6d35a7ec8d0e13a0bed8deb8add3e',1,'Torneo::Torneo()'],['../class_torneo.html#a790fa16486ef92a4f9a1e348492000a5',1,'Torneo::Torneo(const int &amp;c)']]]
];
