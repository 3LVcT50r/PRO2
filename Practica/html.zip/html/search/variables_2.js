var searchData=
[
  ['est_5flocal_185',['est_local',['../class_torneo.html#a331400fae59d62ed861e66969c93cc90',1,'Torneo']]]
];
