var searchData=
[
  ['identificador_5fjugador_150',['identificador_jugador',['../class_lista___jugadores.html#a526cf7437629bc39c95b75c6b9f6b56b',1,'Lista_Jugadores']]],
  ['identificador_5ftorneo_151',['identificador_torneo',['../class_lista___torneos.html#aa9024eb13fa9aa934474851a768de66b',1,'Lista_Torneos']]],
  ['imprimir_5fpuntos_152',['imprimir_puntos',['../class_torneo.html#a28d666a01cdecb47f2c227009569e405',1,'Torneo']]],
  ['imprimir_5fres_153',['imprimir_res',['../class_torneo.html#a6dc9c1f1cacbd52d2bcf85cebd9a2ee7',1,'Torneo']]],
  ['inic_5ftorneo_154',['inic_torneo',['../class_torneo.html#a535b20966a76865f27a26d5a9127c671',1,'Torneo']]],
  ['iniciar_5ftorneo_155',['iniciar_torneo',['../class_lista___torneos.html#aa100284897c9a1ed51613858a66071d6',1,'Lista_Torneos']]]
];
