var searchData=
[
  ['wg_207',['wg',['../class_jugador.html#a7abc588b04284514a4aba2435817584e',1,'Jugador']]],
  ['wm_208',['wm',['../class_jugador.html#a448bdff2f896c579fe35a12febf90eab',1,'Jugador']]],
  ['ws_209',['ws',['../class_jugador.html#a13203866bdb300d84dc7e031d3e27722',1,'Jugador']]]
];
