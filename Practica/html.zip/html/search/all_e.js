var searchData=
[
  ['torn_5fjugados_95',['torn_jugados',['../class_jugador.html#a8ca80640d927c6596cb6668a201aeef9',1,'Jugador']]],
  ['torneo_96',['Torneo',['../class_torneo.html',1,'Torneo'],['../class_torneo.html#a7bf6d35a7ec8d0e13a0bed8deb8add3e',1,'Torneo::Torneo()'],['../class_torneo.html#a790fa16486ef92a4f9a1e348492000a5',1,'Torneo::Torneo(const int &amp;c)']]],
  ['torneo_2ecc_97',['Torneo.cc',['../_torneo_8cc.html',1,'']]],
  ['torneo_2ehh_98',['Torneo.hh',['../_torneo_8hh.html',1,'']]]
];
