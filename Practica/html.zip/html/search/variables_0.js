var searchData=
[
  ['ant_5fparticipantes_182',['ant_participantes',['../class_torneo.html#a7a75e43b363430c6a0ae2fd83e57649b',1,'Torneo']]],
  ['ant_5fpuntos_5fjugador_183',['ant_puntos_jugador',['../class_torneo.html#ad1600dd87d7097af0fee631cb1233637',1,'Torneo']]]
];
