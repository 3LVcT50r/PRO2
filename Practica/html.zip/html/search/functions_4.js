var searchData=
[
  ['hay_5fhistorial_149',['hay_historial',['../class_torneo.html#a55cfd11ee3dbcf8705a748ea98ef51b4',1,'Torneo']]]
];
