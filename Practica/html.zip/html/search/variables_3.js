var searchData=
[
  ['lg_186',['lg',['../class_jugador.html#aeec70c29121310ed184807def7d8feed',1,'Jugador']]],
  ['ljug_187',['ljug',['../class_lista___jugadores.html#ad6af7dd54e4b2eff73ae3a92bc1ea4d8',1,'Lista_Jugadores']]],
  ['lm_188',['lm',['../class_jugador.html#ae1c6aaa82e9b3b7170b77607ffe3887a',1,'Jugador']]],
  ['ls_189',['ls',['../class_jugador.html#a39e2f14dc900e326204456f2d76f5cee',1,'Jugador']]],
  ['ltorn_190',['ltorn',['../class_lista___torneos.html#aae2ca776d802d73c37c37085e65d68e0',1,'Lista_Torneos']]]
];
